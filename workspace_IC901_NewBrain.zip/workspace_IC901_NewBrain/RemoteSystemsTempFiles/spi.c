/********************************************************************
 ************ COPYRIGHT (c) 2017 by KE0FF, Taylor, TX   *************
 *
 *  File name: spi.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  spi memory I/O and API fns.  Also holds memory contents array (32KB)
 *
 *******************************************************************/

#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <math.h>
#include "inc/tm4c1294ncpdt.h"
#include "typedef.h"
#include "init.h"						// App-specific SFR Definitions
#include "cmd_fn.h"						// fn protos, bit defines, rtn codes, etc.
#include "serial.h"
#include "srec.h"
#include "version.h"
#include "spi.h"

#define DEBUG_TRAP						// un-comment if debug
//=============================================================================
// memory array
U8	device_array[256];			// page size of Micron FLASH device
U16	array_len;					// length of device array

U8	sr_ports[8];				// shift register port holding registers. Change these first, then send to the SRs
U8	pota[8];					// "A" pot registers
U8	potb[8];					// "B" pot registers
//=============================================================================
uint8_t write_byte_stream(uint8_t data);
void write_byte_stop(void);
void delay_nss(void);

// ***** START OF CODE ***** //
/****************
 * init_ssi2 initializes SPI resources
 */
void init_ssi2(void){
	U8	i;

	stb_spi();												// init idle state for STB and CS
	close_spi();
	wait(2);												// delat to let GPIOs settle
//	GPIO_PORTD_AHB_DATA_R |= SPCK2;							// set SCK
	for(i=0; i<3; i++){										// clear all shift registers and dpots
//		addr_spi(i);
		send_ssich(0,0,0,0);
	}
	send_ssich(STVOL_ADDR, 0, 0x40, 0);		// sptone at quarter-range, sw to master
}
/****************
 * send_ssich sends pota data to one of 3 channels
 * returns TRUE if channel is valid, else return FALSE
 * potb and srdata are not used, but is retained for API compatibility
 */
U8 send_ssich(U8 addr, U8 srdata, U8 pota, U8 potb){
	U8	temp = TRUE;		// default to valid channel return

	//	set SPI addr
	//	enable CS
	//	send data
	//	close CS (toggle SR STB if channel has a SR)
	switch(addr){
	case MVOL_ADDR:		// MAINVOL
	case SVOL_ADDR:		// SUBVOL
	case STVOL_ADDR:	// SPTONE
		addr_spi(addr);						// pot is TPL0501
		open_spi();
		temp = 255 - pota;					// pots are all backwards, so reverse them here
		send_spi(temp);
		close_spi();
		temp = TRUE;
		break;

	default:
//		temp = potb | srdata;				// ???WTH is this -jmh??? suppresses compiler warnings that we otherwise want to see
		temp = FALSE;
		break;
	}
	return temp;
}
/****************
 * send_spi does bit-bang SPI
 */
uint8_t send_spi(uint8_t data){
	#define BT2	2
	uint8_t	i;
	uint8_t di = 0;

	wait2(BT2);											// delay bit_time/4
	for(i=0x80;i;i>>=1){
//		if(i & data) GPIO_PORTD_AHB_DATA_R |= MOSI2;		// set MOSI
		else GPIO_PORTD_AHB_DATA_R &= ~(MOSI2);
		wait2(BT2);											// delay bit_time/4
//		GPIO_PORTD_AHB_DATA_R &= ~(SPCK2);					// clear SCK
		wait2(BT2);											// delay bit_time/4
		GPIO_PORTD_AHB_DATA_R |= SPCK2;						// set SCK
		wait2(BT2);											// delay bit_time/4
//		if(GPIO_PORTD_AHB_DATA_R & MISO2) di |= i;			// read MISO
		wait2(BT2);											// delay bit_time/4
	}
	wait2(BT2);											// delay bit_time/4
	return di;
}

/****************
 * debug_spi asserts SPI I/O pinis for debug
 */
void debug_spi(U8 addr, U8 spidat){

	if(addr < 8) addr_spi(addr);
	switch(spidat){
	case 0:
//		GPIO_PORTD_AHB_DATA_R ^= MOSI2;		// set MOSI
		break;

	case 1:
//		GPIO_PORTD_AHB_DATA_R ^= SPCK2;		// set SCK
		break;

	case 2:
//		GPIO_PORTD_AHB_DATA_R ^= NSPICS;							// open SPI /CS
		break;

	case 3:
		send_spi(0xaa);
		break;

	default:
		close_spi();
		GPIO_PORTD_AHB_DATA_R &= ~(MOSI2);	// clear MOSI
		GPIO_PORTD_AHB_DATA_R &= ~(SPCK2);	// clear SCK
		GPIO_PORTL_DATA_R |= (NSR_STB);		// stb = inactive
		addr_spi(0);
	}
	return;
}

/****************
 * send_spi1 sends a 1 byte message to the SPI device
 */
void send_spi1(uint8_t data){

//	GPIO_PORTD_AHB_DATA_R |= (NSPICS);							// close SPI /CS
	send_spi(data);
	GPIO_PORTD_AHB_DATA_R &= ~(NSPICS);							// enable SPI /CS
	return;
}

/****************
 * addr_spi sets the 3-bit SPI device select address
 */
void addr_spi(uint8_t addr){

	// set SPI addr
	GPIO_PORTL_DATA_R = (GPIO_PORTL_DATA_R & MASK_SPICS) | addr;
	wait(2);
	return;
}

/****************
 * open_spi starts an spi message by lowering CS
 */
void open_spi(void){

//	GPIO_PORTD_AHB_DATA_R |= (NSPICS);							// open SPI /CS
	wait(BT2);
	return;
}

/****************
 * close_spi closes an spi message by raising CS
 */
void close_spi(void){

	wait(BT2);
//	GPIO_PORTD_AHB_DATA_R &= ~(NSPICS);							// close SPI /CS
	return;
}

/****************
 * stb_spi toggles the NSR_STB GPIO (for the shift registers)
 */
void stb_spi(void){

	GPIO_PORTL_DATA_R &= (~NSR_STB);						// pulse stb
	wait2(30);												// delay
	GPIO_PORTL_DATA_R |= (NSR_STB);
	return;
}

//=============================================================================
// M24P40 Fns follow

/****************
 * send_spi3 does bit-bang SPI for port3 <<< place holder for QSPI implementation >>>
 */
uint8_t send_spi3(uint8_t data){

#if USE_QSPI

	uint8_t di = 0;

	SSI3_ICR_R = SSI_ICR_EOTIC;							// pre-clear EOT flag
	SSI3_DR_R = data;
	while((SSI3_RIS_R & SSI_RIS_EOTRIS) == 0);			// wait for eot
	di = SSI3_DR_R;
	SSI3_ICR_R = SSI_ICR_EOTIC;							// clear EOT flag
	return di;

#else
	uint8_t	i;
	uint8_t di = 0;

	for(i=0x80;i;i >>= 1){
		if(i & data) GPIO_PORTQ_DATA_R |= MOSI3;		// set MOSI
		else GPIO_PORTQ_DATA_R &= ~(MOSI3);
		wait2(10);										// delay bit_time/2
		GPIO_PORTQ_DATA_R |= SPCK3;						// set SCK
		if(GPIO_PORTQ_DATA_R & MISO3) di |= i;			// read MISO
		wait2(10);										// delay bit_time/2
		GPIO_PORTQ_DATA_R &= ~(SPCK3);					// clear SCK
	}
	return di;
#endif
}

/****************
 * spi3_clean clears out the rx fifo.
 */
void spi3_clean(void){
	volatile uint8_t di = 0;

#if USE_QSPI
	while(SSI3_SR_R & SSI_SR_RNE){				// repeat until FIFO is empty
	di = SSI3_DR_R;
	}
#endif
	return;
}

/****************
 * send_spi31 sends a 1 byte message to the SPI3 device
 */
void send_spi31(uint8_t data){

	GPIO_PORTQ_DATA_R &= ~(NFSS3);							// enable SPI /CS
	send_spi3(data);
	delay_nss();
	GPIO_PORTQ_DATA_R |= (NFSS3);							// close SPI /CS
	return;
}

/****************
 * read_mema returns data in memory array
 */
uint8_t read_mema(uint32_t *addr){

//	return device_array[*addr];
	return read_byte(*addr);
}

/****************
 * write_mema puts data in memory array
 */
void write_mema(uint32_t* addr, uint8_t data){

	write_enab();							// enable flash writes
	write_byte(*addr, data);
	wait_wip();
}

/****************
 * write_enab enables writes to SPI device
 */
void write_enab(void){

	send_spi31(M24P40_WREN);
}
/****************
 * write_disab disables writes to SPI device
 */
void write_disab(void){

	send_spi31(M24P40_WRDI);
}
/****************
 * write_bulke does bulk erase
 */
void write_bulke(void){

	send_spi31(M24P40_BULK);
}
/****************
 * write_secte does sector erase
 */
void write_secte(uint32_t addr){

	GPIO_PORTQ_DATA_R &= ~(NFSS3);								// enable SPI /CS
	send_spi3(M24P40_SECT);
	send_spi3((uint8_t)((addr >> 16) & 0xff));
	send_spi3((uint8_t)((addr >> 8) & 0xff));
	send_spi3((uint8_t)(addr & 0xff));
	delay_nss();
	GPIO_PORTQ_DATA_R |= (NFSS3);								// close SPI /CS
}
/****************
 * read_stat reads a READ status byte from the SPI device (cmd is read or write status cmd)
 */
uint8_t read_stat(void){
	uint8_t data;

	GPIO_PORTQ_DATA_R &= ~(NFSS3);								// enable SPI /CS
	send_spi3(M24P40_RDSR);
	data = send_spi3(0x00);
	delay_nss();
	GPIO_PORTQ_DATA_R |= (NFSS3);								// close SPI /CS
	return data;
}
/****************
 * wait_wip reads a READ status byte from the SPI device until WIP == 0
 */
void wait_wip(void){
	uint8_t data;

	GPIO_PORTQ_DATA_R &= ~(NFSS3);								// enable SPI /CS
	send_spi3(M24P40_RDSR);
	do{
		data = send_spi3(0x00);									// read status...
	}while((data & M24P40_WIP) && !is_esc());									// until WIP == 0
	GPIO_PORTQ_DATA_R |= (NFSS3);								// close SPI /CS
	return;
}
/****************
 * write_stat writes the status byte to the SPI device
 */
uint8_t write_stat(uint8_t status){
	uint8_t data;

	GPIO_PORTQ_DATA_R &= ~(NFSS3);								// enable SPI /CS
	send_spi3(M24P40_WRSR);
	data = send_spi3(status);
	delay_nss();
	GPIO_PORTQ_DATA_R |= (NFSS3);								// close SPI /CS
	return data;
}
/****************
 * read_byte reads a mem byte from the SPI device
 */
uint8_t read_byte(uint32_t addr){
	uint8_t data;

	GPIO_PORTQ_DATA_R &= ~(NFSS3);								// enable SPI /CS
	send_spi3(M24P40_READ);
	send_spi3((uint8_t)((addr >> 16) & 0xff));
	send_spi3((uint8_t)((addr >> 8) & 0xff));
	send_spi3((uint8_t)(addr & 0xff));
	data = send_spi3(0x00);
	GPIO_PORTQ_DATA_R |= (NFSS3);								// close SPI /CS
	return data;
}
/****************
 * read_id reads id bytes from the SPI device
 */
uint8_t read_id(char *ptr){
	uint8_t	len = 0;			// length of returned array
	uint8_t	clen;				// length of CFD sub-array
	uint8_t	i;					// cfd loop temp

	GPIO_PORTQ_DATA_R &= ~(NFSS3);								// enable SPI /CS
	send_spi3(M24P40_ID);
	*ptr++ = (char)send_spi3(0x00);									// get MFR
	len += 1;
	*ptr++ = (char)send_spi3(0x00);									// get devid1
	len += 1;
	*ptr++ = (char)send_spi3(0x00);									// get devid2
	len += 1;
	clen = send_spi3(0x00);										// get cfd length
	*ptr++ = (char)clen;
	len += 1;
	for(i=0;i<clen;i++){
		*ptr++ = (char)send_spi3(0x00);								// get devid2
		len += 1;
	}
	GPIO_PORTQ_DATA_R |= (NFSS3);								// close SPI /CS
	return len;
}


/****************
 * read_byte_start reads a mem byte from the SPI device by sending addr,
 * but keeps CS low for next byte to read.  Waits until 1st byte is ready,
 * but does not read.
 */
void read_byte_start(uint32_t addr){

	GPIO_PORTQ_DATA_R &= ~(NFSS3);						// enable SPI /CS
	send_spi3(M24P40_READ);
	send_spi3((uint8_t)((addr >> 16) & 0xff));
	send_spi3((uint8_t)((addr >> 8) & 0xff));
	send_spi3((uint8_t)(addr & 0xff));
	SSI3_ICR_R = SSI_RIS_EOTRIS;						// pre-clear EOT flag
	SSI3_DR_R = 0x00;									// fetch next byte
	return;
}

/****************
 * read_byte_stream reads data byte from SPIDR, then starts a new xfr.
 */
uint8_t read_byte_stream(void){
	uint8_t di = 0;

	while((SSI3_RIS_R & SSI_RIS_EOTRIS) == 0);			// wait for eot of last
	di = SSI3_DR_R;
	SSI3_ICR_R = SSI_RIS_EOTRIS;						// clear EOT flag
	SSI3_DR_R = 0x00;									// fetch next byte
	return di;
}

/****************
 * read_byte_stop sets CS high to terminate read cycle
 */
void read_byte_stop(void){

	GPIO_PORTQ_DATA_R |= (NFSS3);							// disable SPI /CS
	spi3_clean();											// clean out the FIFO
}

/****************
 * write_byte writes a mem byte to the SPI device
 */
void write_byte(uint32_t addr, uint8_t data){

	GPIO_PORTQ_DATA_R &= ~(NFSS3);								// enable SPI /CS
	send_spi3(M24P40_WRITE);
	send_spi3((uint8_t)((addr >> 16) & 0xff));
	send_spi3((uint8_t)(addr >> 8));
	send_spi3((uint8_t)(addr & 0xff));
	send_spi3(data);
	delay_nss();
	GPIO_PORTQ_DATA_R |= (NFSS3);								// close SPI /CS
}

/****************
 * delay_nss() does a quick delay for nss hold time
 */
void delay_nss(void){
	uint8_t	i;		// temp

	for(i=0;i<20;i++);
}
/****************
 * write_byte_stream reads data byte from SPIDR, then starts a new xfr.
 */
uint8_t write_byte_stream(uint8_t data){
	uint8_t di = 0;

	while((SSI3_SR_R & 0x04) == 0);						// wait for data ready
	SSI3_DR_R = data;									// send next byte
	di = SSI3_DR_R;										// get rcv data
	return di;
}

/****************
 * write_byte_stop sets CS high to terminate read cycle
 */
void write_byte_stop(void){

	GPIO_PORTQ_DATA_R |= (NFSS3);								// disable SPI /CS
}

/****************
 * write_page_start starts a page pgm cycle, writes 1st byte to the SPI device
 */
void write_page_start(uint32_t addr){

	GPIO_PORTQ_DATA_R &= ~(NFSS3);								// enable SPI /CS
	send_spi3(M24P40_WREN);
	GPIO_PORTQ_DATA_R |= (NFSS3);								// close SPI /CS

	GPIO_PORTQ_DATA_R &= ~(NFSS3);								// enable SPI /CS
	send_spi3(M24P40_WRITE);
	send_spi3((uint8_t)((addr >> 16) & 0xff));
	send_spi3((uint8_t)((addr >> 8) & 0xff));
	send_spi3((uint8_t)(addr & 0xff));
//	send_spi3(data);											// send d[7:0]
}

/****************
 * write_byte writes the device_array to the SPI device.
 * returns next device addr to be programmed
 */
uint32_t write_page(uint32_t addr){
	uint16_t	index = 0;						// start at beginning of data array
	uint8_t		start_flag = 1;					// page pgm start armed
	uint32_t	paddr;							// page mode device address

	paddr = addr;												// set start addr
	do{
		if(start_flag == 1){									// if start armed,
			write_page_start(paddr);							// open page pgm
			start_flag = 0;										// dis-arm start
		}
		send_spi3(device_array[index++]);						// send data from array
		if((++paddr & 0xff) == 0x00){							// end of page
			GPIO_PORTQ_DATA_R |= (NFSS3);						// close SPI /CS
			wait_wip();											// wait for pgmd done
			start_flag = 1;										// re-arm start
		}
	}while(index < array_len);									// until end of array
	if(start_flag == 0){										// didn't get to end of page,
		GPIO_PORTQ_DATA_R |= (NFSS3);							// close SPI /CS
		wait_wip();												// wait for pgmd done
	}
	return paddr;
}

/****************
 * set_spi is an SPI test fn.  Cycles all SPI I/Os based on count value "spi_state"
 */
#ifdef DEBUG_TRAP
void set_spi(uint8_t spi_state){

	switch(spi_state){
	default:
	case 0:
		GPIO_PORTQ_DATA_R &= ~(MOSI3|NFSS3|SPCK3);
		break;

	case 1:
		GPIO_PORTQ_DATA_R ^= (SPCK3);
		break;

	case 2:
		GPIO_PORTQ_DATA_R ^= (MOSI3);
		break;

	case 3:
		GPIO_PORTQ_DATA_R ^= (NFSS3);
		break;

	case 4:
		if(GPIO_PORTQ_DATA_R & MISO3){
			putss("1");
		}else{
			putss("0");
		}
		break;
	}
}
#endif
