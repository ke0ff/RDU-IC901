/********************************************************************
 ************ COPYRIGHT (c) 2025 by ke0ff, Taylor, TX   *************
 *
 *  File name: serial.h
 *
 *  Module:    Control
 *
 *  Summary:   This is the header file for serial I/O.
 *
 *******************************************************************/


/********************************************************************
 *  File scope declarations revision history:
 *    07-30-14 jmh:  creation date
 *
 *******************************************************************/

#include	"init.h"

//------------------------------------------------------------------------------
// extern defines
//------------------------------------------------------------------------------
//#define TIMER_MIS_AMASK	(TIMER_MIS_TAMMIS | TIMER_MIS_CAEMIS | TIMER_MIS_CAMMIS | TIMER_MIS_TATOMIS)

#define	ENAB_UART4

#define	UP14	(COMP_ACSTAT_OVAL >> 1)
#define	DN14	COMP_ACSTAT_OVAL
#define	OP14	0

#define	HM_BUFF_END		20			// HM-1xx MFmic buffer length
// MFmic HM-key state machine defines
#define	HMST_IDLE		1			// initial state
#define	HMST_PRESS		2			// pressed state: "h" or "r/R" to exit
#define	HMST_HOLD		3			// hold state: "r/R" to exit
#define	HMST_REL		4			// release debounce

//------------------------------------------------------------------------------
// public Function Prototypes
//------------------------------------------------------------------------------

char process_HM133(U8 flag);

void initserial4(void);
U32 init_uart4(U32 baud);
U32 config_uart4(U32 baud);
char set_baud4(U32 baud);
char getchr4(void);
char gotchr4(void);
U8 gotmsgn4(void);
char getchr_b4(void);
char gotchr_b4(void);
char* getss4(char* dptr);
char getch04(void);
char* get_btptr4(void);
void clr_btptr4(void);
S8 updn14(void);
void rxd4_intr(void);
void Timer3A_ISR(void);
void timer3A_init(U32 sys_clk);

U8 hm_asc(void);
char process_CMD(U8 flag);
U8 set_shift(U8 tf);
void pttsub_togg(U8 bflags);
void hm_map(U8 cm, U8 hm);
