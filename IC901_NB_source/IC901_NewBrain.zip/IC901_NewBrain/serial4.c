///******************************************************************************************
//		serial4.c
//
//		Copyright (c), Aug 2025, all rights reserved.
//		Joseph Haas
//		KE0FF
//		www.ke0ff.org
//
//		Multi-Function Microphone interface application for the Tiva IC-901F application.
//
//		This application is modified from the IC-900 RDU Clone project, multi-function microphone interface.
//		The MFMIC uses the UP/DN signal on the IC-901F microphone connector (intercepted inside
//		the IC-901 "Base-Unit" or pass-thru via the EX-766) to transfer keypress data from an HM-133 DTMF
//		adapter interface to the IC-901F.
//
//		The IC-901F has UART4 assigned to the connection, so there is no need to share the UART with the CLI.
//		Thus, the SW only needs to read characters and interpret them against the HM-133 requirements.
//		The MFmic data monitored by the ATtiny application allows the ATtiny to "replace" the UP/DN button
//		functionality as follows:
//
//			1) An analog up-dn mic is used (such as the HM-14) -- The IC-901F monitors the comparators
//				and produces a calculation that determines if "UP" or "DN" are pressed.  These states
//				are echoed to GPIO pins that connect to the A-unit up/dn input.  In this state, the data
//				switch is forced to the remote PC input (regardless of the RTS status) to prevent button
//				presses from being passed to the RDU as false UART traffic.  The ADC used in the ATTINY
//				version is effectively replaced with a 2-bit ADC that has three states: 0, 1, or 2 to
//				relate the voltage on the MU/D2 signal.
//
//				The main point to the buffering is to filter out HM-133 serial traffic that might trigger
//				occasional false dn detections.  Requiring 3 sequential detections in 15ms is sufficient
//				filter the 5-byte HM-133 message at 115.2 Kb.
//
//			2) An HM-133 is connected -- In this case, the serial data is passed to the HM133 processor code.
//
//		Automatic mic detection is employed using the following "clues":
//			1) [analog]: a 0x00 byte (NULL) is received at the UART input.  This is indicative of the UP button
//				(GND) being pressed and signals that an analog mic is connected.
//			2) [analog]: a "DN" voltage is detected for at least tdn(min).
//			3) [digital]: any valid HM-133 message is detected in the UART datastream.  This signals that an
//				HM-133 interface is present.  The message validation happens before the parsing, so there is
//				no data loss if the first message is an UP or DN button.
//
//		SW requirements:
//		The UP/DN comparator signals are "digitized" & buffered by the Tiva comparators (C0 & C1) at a 5ms rate.
//		The comparator result, stored into a 3-element wrap-around U8 array, is scanned by a polling routine to
//		determine if a button press is indicated.  If all elements of the array are the same, then the contents
//		(by definition) determine the type of button event (UP, DN, or OPEN).
//
//		An algorithm shall be deployed to jog between the serial commands and the HM-14 buttons. The IPL default
//		is analog buttons.  A serial break or 3 consecutive "DN" readings invokes HM-14 mode.  In HM-14 mode,
//		the "ADC" buffer determines the UP and DN state.  The signals are used to communicate analog U/D presses
//		to the process_dial() function.  If a valid serial command is decoded from the HM-133, the serial mode
//		is established.  This method allows for the microphones to be hot swapped without any additional operator
//		intervention.
//
//		This system doesn't use the cmd_fn pathway to process UART signals, so the UART messages will need to
//		be buffered and processed herein, with U/D signals (poss. the same ones used for analog buttons).
//
//		A "loss of remote" timer shall to be maintained to prevent the UP/DN outputs from being "locked up"
//		should there be a loss of data from the HM-133 interface.  Valid "HOLD" messages reset the timer.
//		if the timer reaches zero, the U/D signals are released.
//
//		HM-133 commands are 5-bytes long: <'~'><cmd><p/h/r/R><chk><\r>
//				<'~'> is fixed preamble
//				<cmd> is a single-byte alpha-numeric command
//				<p/h/r/R> is a single character for key (p)ress, (h)old, dn (r)elease, or up (R)elease
//				<chk> = (<cmd> EOR <p/h/r/R>) OR 0x80
//				<\r> is <CR>, ASCII 0x0d
//
//		Uses these peripherals:
//
//		PK0:		UART4 RXD, 115200b, N81
//		PC4:		C1-		2.2Vref (only Dn will activate)
//		PC5:		C1+
//		PL3:		C1o
//		PC7:		C0-		1.1Vref (Up or Dn will activate)
//		PC6:		C0+
//		PL2:		C0o
//		Timer3A		pacing timer (5ms) for "ersatz ADC" comparator-digitizer
//
//
//		IC-901F (remapped) HM-133 KEYPAD:
//
//		MHz (L)		CALL (T)	M/S (X)
//		MHz {p}		CALL {o}	M/S {n}
//
//		UP (/)		V/M (V)		H/L (M)
//		UP {k}		MW {m}		H/L {l}
//
//		DN (\)		n/u (F)		Fn (G)							F & G keys only report from HM-151
//		DN {j}		n/u {|}		Fn {!}
//
//		(1)			(2)			(3)			TONE (A)			<Digits 0-9 = DTMF if PTT active>
//		BL+ {a}		RBnk+ {b}	Q+ {c}		V+ {q}
//
//		(4)			(5)			(6)			SUB (B)
//		BL- {d}		RBnk- {e}	Q- {f}		V- {r}
//
//		(7)			(8)			(9)			BAND (C)
//		DUP- {g}	DUP+ {h}	S {i}		PTTsub itg {s}
//																-% The toggle CHECK feature sets the check switch,
//		ABRT (*)	(0)			ENT (#)		SMUTE (D)			then enters a special hold state.  Any bluethooth
//		TS {+}		{`}			{$}			PTTsub Mode {t}		key will then open the CHECK button, exit the hold'
//
//		() characters are non-Fn shifted
//		{} characters are Fn mode shifted
//
//		The above HM-133 key-codes get mapped to the IC-901 FP buttons in this module.  Fn-shift is also managed here.
//
//**************************************************************************************************************-jhaas

/////////////////////// REVISION NOTES //////////////////////////
//
// Rev 0.0, 08-17-25, jmh		debug and port-issue containment
// 			08-14-25, jmh		initial creation revision (some elements copied from ATTINY MFMIC app)
// Origin Date: 08-14-25
/////////////////////////////////////////////////////////////////

#include <stdint.h>
#include "inc/tm4c1294ncpdt.h"
#include "typedef.h"
#include "init.h"
#include "stdio.h"
#include "serial4.h"
#include "serial.h"
#include "cmd_fn.h"
#include "lcd.h"
#include "nvic.h"
#define UART4_ENABLED

//------------------------------------------------------------------------------
// Define Statements
//------------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Local Variable Declarations
//-----------------------------------------------------------------------------


// UART4 control flags & regs (DEBUG CLI I/O)
U8  bteol;						// BT eol detected
U8  TI4B;						// UART0 TI0 reflection (set by interrupt)
#define RXD4_BUFF_END	80		// CCMD rx buff len

S8  volatile rxd4_buff[RXD4_BUFF_END];	// rx data buffer
U8  volatile rxd4_hptr;					// rx buf head ptr
U8  volatile rxd4_tptr;					// rx buf tail ptr
U8  volatile rxd4_stat;					// rx buff status
U8	volatile rxd4_mcnt;					// msg (EOL) count

#define	ADC_LEN			3
U8	volatile ud_adc[ADC_LEN];			// ersatz ADC buffer
U8	ud_adc_idx;
U8	ud_reg;
U8	udwait;
#define	HOLD_TIME		(750/5)				// 5ms per Timer3A tic
#define	DBNCE_TIME		(60/5)
U8	ud_state;
#define	UD_IDLE			0
#define	UD_UPDN			1
#define	UD_WAIT			3

// HM-133 MFmic support
U8	hm_buf[HM_BUFF_END];				// signal buffer
U8	hm_hptr;
U8	hm_tptr;
U8	shftm;								// fn-shift mem register (MFmic)
U8	key_count;
char key_hold;
S8	ud_hm133;

#define	HM_CLILEN		10
char	hm_cmdbuf[HM_CLILEN];
//-----------------------------------------------------------------------------
// Local Fn Declarations
//-----------------------------------------------------------------------------

S8 is_updn14(void);
void hm_cmd_exec(char* sptr, U8 cmd);
void hm_sto(U8 j);


  /*********************
	UART4 Init routines
   *********************/

//-----------------------------------------------------------------------------
// initserial4() initializes serial & adc buffers and fn state machines
//	for the HM-133/HM-14 up/dn interface
//-----------------------------------------------------------------------------
void initserial4(void){
	U8	i;

    TI4B = 1;
    rxd4_hptr = 0;
    rxd4_tptr = 0;
    rxd4_stat = 0;
    rxd4_mcnt = 0;
    ud_adc_idx = 0;
    udwait = 0;
    ud_state = UD_IDLE;
    for(i=0; i<ADC_LEN; i++){
    	ud_adc[i] = 0;
    }
    init_uart4(115200L);
}

/****************
 * init_uart inits UART0 to (baud), N81
 */
U32 init_uart4(U32 baud)
{
	U32	i;

	SYSCTL_RCGCUART_R |= SYSCTL_RCGCUART_R4;			// enable UART4 peripheral
	GPIO_PORTK_AFSEL_R |= 0x0003L;						// connect UART4 RX & TX to PA0 & PA1
	GPIO_PORTK_PCTL_R &= 0xFFFFFF00L;					// enable UART4 function
	GPIO_PORTK_PCTL_R |= 0x0011L;
	GPIO_PORTK_DEN_R |= 0x0003;							// RXD = digital
	for(i=0;i<100000;i++);
	return config_uart4(baud);							// config UART4
}

/****************
 * config_uart4 inits UART4 to (baud), N81
 */
U32 config_uart4(U32 baud)
{
	U32	IR;
	U32	i;

	UART4_CTL_R &= 0xfffffffeL;							// disable UART
	UART4_CTL_R &= 0xffff33ffL;							// disable HS, leave TE and RE alone
	IR = (uint32_t)SYSCLK * 4L;							// IR = (sysclk * 64) / (16 * baud)
	IR /= baud;											//    = sysclk * 4 /baud
	UART4_IBRD_R &= 0xffff0000L;
	UART4_IBRD_R = (IR>>6) & 0xffff;
	UART4_FBRD_R &= 0xffffffc0L;
	UART4_FBRD_R |= IR & 0x3fL;
//	UART4_CC_R = UART_CC_CS_PIOSC;						// set PIOSC as UART source
	UART4_CC_R &= UART_CC_CS_M;							// set SYSCLK as UART source
	UART4_CC_R |= UART_CC_CS_SYSCLK;					// set SYSCLK as UART source

	UART4_LCRH_R |= 0x0060L;							// 8 bits
//	UART4_IM_R &= 0xfffce000L;							// set UART0 to int on RX
	UART4_IM_R = UART_IM_RXIM;							// enable RX interrupt
	UART4_CTL_R |= 0x0300L;								// set TE and RE
	UART4_CTL_R |= 0x0001L;								// enable UART
	NVIC_EN1_R = NVIC_EN1_UART4;						// enable UART in the NVIC
	for(i=0;i<100000;i++);								// delay a bit...
	return IR+4;
}

//-----------------------------------------------------------------------------
// set_baud() sets baud rate to passed value (if supported).  If rate is valid,
//	return TRUE, else FALSE.  0 = 115,200 baud
//-----------------------------------------------------------------------------
char set_baud4(U32 baud){

	char c = FALSE;
	
	switch(baud){
		case 9600L:
		case 19200L:
		case 38400L:
		case 57600L:
		case 115200L:
			config_uart4(baud);
			c = TRUE;
			break;

		case 0L:
			config_uart4(115200L);
			c = TRUE;
			break;
	}
	return c;
}

//*****************************************************************************
//	Timer3A drives the 0.005s ersatz ADC
//*****************************************************************************
void timer3A_init(U32 sys_clk){
	volatile U32	ui32Loop;

	// init timer3A for interrupts
	SYSCTL_RCGCTIMER_R |= SYSCTL_RCGCTIMER_R3;			// enable timer 2 clock domain
	ui32Loop = SYSCTL_RCGCGPIO_R;
	TIMER3_CTL_R &= ~(TIMER_CTL_TAEN);					// disable timer
	TIMER3_CFG_R = TIMER_CFG_16_BIT; //0x4; //0;
	TIMER3_TAMR_R &= ~(TIMER_TAMR_TAMR_M);
	TIMER3_TAMR_R |= TIMER_TAMR_TAMR_PERIOD;
	TIMER3_TAPR_R = TIMER3A_PS;							// timer 3B prescale
	TIMER3_TAILR_R = (uint16_t)(sys_clk/(TIMER3A_FREQ * (TIMER3A_PS + 1)));
	TIMER3_IMR_R |= TIMER_IMR_TATOIM;					// enable timer intr
	TIMER3_CTL_R |= TIMER_CTL_TAEN;						// enable timer
	NVIC_EN1_R = NVIC_EN1_TIMER3A;						// enable timer3A intr in the NVIC_EN regs
}

//=================== UART4 processing ================================

//-----------------------------------------------------------------------------
// gotmsgn returns the rcvd msg count.
//-----------------------------------------------------------------------------
U8 gotmsgn4(void){

	return rxd4_mcnt;
}


//-----------------------------------------------------------------------------
// getss() gets string from input buffer and xfrs to dptr
//-----------------------------------------------------------------------------
char* getss4(char* dptr){
	char c;
	char* cptr = dptr;

	if(rxd4_mcnt){
		do{
			c = getch04();
			*cptr++ = c;
		}while(c);
		rxd4_mcnt--;
	}
	return cptr;
}

//-----------------------------------------------------------------------------
// getch04 checks for input @ RX4.  If no chr, wait forever.
//	waits for a chr and returns.  Note: Processor spends most of its idle
//	time waiting in this fn.
//	looks for input in rxd_buff[] which is filled in the UART4 interrupt
//-----------------------------------------------------------------------------
char getch04(void){

	char c = '\0';

	if(rxd4_tptr != rxd4_hptr){
		c = rxd4_buff[rxd4_tptr++];
		if(rxd4_tptr == RXD4_BUFF_END){
			rxd4_tptr = 0;
		}
	}
	return c;
}


//=================== HM-133 processing ================================

//-----------------------------------------------------------------------------
// process_HM133() processes HM133 data inputs
//-----------------------------------------------------------------------------
char process_HM133(U8 flag){

	if(flag == INIT_PROCESS){
		// init process
		initserial4();
		hm_cmd_exec(hm_cmdbuf, INIT_PROCESS);
	}
	if(gotmsgn4()){
		getss4(hm_cmdbuf);
		if(hm_cmdbuf[0] == '~'){								// process HM keys
			hm_cmd_exec(hm_cmdbuf, 0);
		}
	}
	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// hm_cmd_exec() executes the hm command intercept and fills the hm_buf[]
//	with keypress actions from the MFmic interface.  This stream gets merged
//	with the main button stream inside main().
//	This gets called once for each MFmic key packet received.  MFmic packets
//	all start with '~'.  Valid packets have the following format:
//		pcsk\r
//		p = '~'
//		c = command chr
//		s = status chr
//		k = check = (c ^ s) | 0x80
//		\r = carriage return (this is stripped by the cmd-ln pre-processing
//			 and thus becomes a '\0' character)
//		'c' and 's' are printable ASCII. 'k' is made to be a non-ASCII character
//			by virtue of the hi-bit being set.  Setting the hi-bit also guarantees
//			that the check won't ever be a null, allowing standard null-terminated
//			array handling to be valid.
//-----------------------------------------------------------------------------
void hm_cmd_exec(char* sptr, U8 pcmd){
		U8	cm;				// extracted command
		U8	hm;				// extracted press/hold/release status
		U8	j;				// temp
static	U8	hm_state;		// state machine process variable
static	U8	cm_last;		// last cmd
//static	U8	hm_last;		// last status

	// IPL init of statics
	if(pcmd == INIT_PROCESS){
		hm_map(0xff, 0xff);
		hm_state = HMST_IDLE;
//		hm_last = '\0';
		cm_last = '\0';
		return;
	}
	// calculate check-digit -- check = (cmd ^ param) | 0x80
	j = (*(sptr+1) ^ *(sptr+2)) | 0x80;
	// if command packet valid, process state machine
	if((j == *(sptr+3)) && (*(sptr+4) == '\0')){
		// capture command and press/hold/release status from the packet payload
		cm = *(sptr+1);
		hm = *(sptr+2);
		// state machine to process key press-hold-release sequence
		switch(hm_state){
		default:
		case HMST_IDLE:
			// look for a press or hold (if we see a hold here, we assume that the press packet was missed)
			if((hm == 'p') || (hm == 'h')){
				hm_map(cm, 'p');					// map initial keypress into signal buffer
				hm_state = HMST_PRESS;				// point to next state
				hmk_time(1);						// start hold timer (the same hold delay time as for the panel buttons)
				cm_last = cm;						// save the command.  Us this saved value for subsequent actions until release
			}
			break;

		case HMST_PRESS:
			if(cm_last != cm){
				putsQ(("#")); //!!!
			}
			// At this point in the process, hold or release is expected
			// a press is assumed to be a repeat press packet and is ignored
			switch(hm){
			case 'R':
			case 'r':
				hm_map(cm_last, 'r');				// map release into signal buffer
				hm_state = HMST_IDLE;				// return to start
				break;

			case 'h':
				if(!hmk_time(0)){					// if "hold" is indicated AND there is a timeout:
					hm_map(cm_last, hm);			// map hold keypress into signal buffer
					hm_state = HMST_HOLD;			// point to next state
					hmk_time(1);					// reset hold timer
				}
				break;

			default:
				putsQ(("@")); //!!!
				break;
			}
			break;

		case HMST_HOLD:
			// if there is a timeout of the hmk_timer, we assume a critical loss and force the keypress to be released
			if(!hmk_time(0)){
				hm = 'r';							// force release
			}
			// once the hold mode is encountered, we look for release or a timeout (loss of comms from the MFmic).
			switch(hm){
			default:
				break;

			case 'h':								// a valid hold packet resets the timeout
				hmk_time(1);
				break;

			case 'R':								// valid release
			case 'r':
				hm_map(cm_last, 'r');				// map release keypress into signal buffer
				hm_state = HMST_IDLE;				// point to next state
				cm_last = '\0';						// clear cmd mem
				break;

			// a press here is an error.  Assume that the release of the previous key was lost & start a new press sequence
			case 'p':
				// process the release of the previous key
				hm_map(cm_last, 'r');				// map release keypress into signal buffer
				// start a new press
				hm_map(cm, 'p');					// map keypress into signal buffer
				hm_state = HMST_PRESS;				// point to next state
				hmk_time(1);						// start hold timer
				cm_last = cm;						// set cmd mem
				break;
			}
			break;
		}
	}else{
		putsQ("HMsgerr");
	}
	return;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// hm_map() maps the MFmic hm command intercept to a local key ID and fills the hm_buf[]
//	cm = key code (ASCII, maps to keypad on HM-133 interface)
//	hm = (p)ress/(h)old/(r)elease
//-----------------------------------------------------------------------------
//char keychr_lut[] = {  TSchr, };
void hm_map(U8 cm, U8 hm){
	volatile U8	j;		// temps
//	U8	i;
//	char lcdbuf[4];

	// trap IPL init
	if(cm == 0xff){
		shftm = 0;
		// init process indicator
		aprog(0);
		return;
	}
	if(hm == 0){
		putsQ("hm=0");
	}
	// trap null inputs
	if((cm == '\0') || (hm == '\0')){
		return;
	}
	if(!shftm){
		switch(cm){
		default:
			break;

//		case SH_LOKEY:
		case SH_CALLKEY:
		case SH_XFCKEY:
		case SH_UPKEY:
		case SH_VMKEY:
		case SH_MWKEY:
		case SH_DNKEY:
		case SH_F1KEY:
		case SH_F2KEY:
		case SH_1:
		case SH_2:
		case SH_3:
		case SH_A:
		case SH_4:
		case SH_5:
		case SH_6:
		case SH_B:
		case SH_7:
		case SH_8:
		case SH_9:
		case SH_C:
		case SH_STR:
		case SH_0:
		case SH_PND:
		case SH_D:
			set_shift(1);
			shftm = 1;
			aprog(1);
			do_1beep();
			shft_time(1);								// start the shift timer
			break;
		}
	}
	// map keys with shift mode active
	if(shftm == 1){
		shft_time(1);									// kick the shift timer
		switch(cm){
			default:
				set_shift(0);
				shftm = 0;								// undefined keys cancel shift mode
				j = '\0';
				// clear process indicator
				aprog(0);
				do_1beep();
				break;

			case F2KEY:
			case LOKEY:
			case SH_LOKEY:								// (FUNC-LOCK) == shift-toggle key
				j = '\0';
				if(hm == 'p'){
					set_shift(0);
					shftm = 0;
					// update process indicator
					aprog(0);
					do_2beep();
				}
				break;

			case '\\':
				if(hm == 'p'){
					ud_hm133 -= 1;
					do_1beep();
				}
				j = '\0';
				break;

			case '/':
				if(hm == 'p'){
					ud_hm133 += 1;
					do_1beep();
				}
				j = '\0';
				break;

			case SH_CALLKEY:
			case CALLKEY:
				j = SETchr;
				break;

			case SH_XFCKEY:
			case XFCKEY:
				if(hm == 'p'){
					j = SUBchr;
				}
				break;

			case SH_VMKEY:
			case VMKEY:
				j = MWchr;
				break;

			case SH_3:
			case '3':
				j = Qupchr;
				break;

			case SH_6:
			case '6':
				j = Qdnchr;
				break;

			case SH_A:
			case 'A':
				j = Vupchr;
				break;

			case SH_B:
			case 'B':
				j = Vdnchr;
				break;

/*  			case 'C':			// read PTTSUB
  				putsQ("isC");
			case SH_C:
  				// only act on press cmd
  				if(hm == 'p'){
  	  				// bflags hold the pttsub action status.  read the current bflags
//  	  				i = get_bflag(MAIN, 0, 0);
//  	  				j = i & PTTSUB_M;
  	  				// response beeps indicate status
  	  				switch(j){
  	  				case PTTSUB_MOD0:
  	  					put_stat(MAIN, "PTTSUB OFF");
  	  					do_1beep();
  						break;

  	  				case PTTSUB_MOD1:
  	  					put_stat(MAIN, "PTTSUB SMUTE");
  	  					do_2beep();
  	  					break;

  	 				case PTTSUB_MOD2:
  	  					put_stat(MAIN, "PTTSUB SCALL");
  	  					do_3beep();
  						break;

  	 				default:
  	  				case PTTSUB_MOD3:
  	  					put_stat(MAIN, "PTTSUB MCALL");
  	  					do_4beep();
  	 					break;
  	 				}
  				}
				j = '\0';
				break;*/

//			case SH_D:
//  			case 'D':			// set PTTSUB
// 				j = FDchr;
//				break;

  			case SH_PND:
  			case '#':		// null - do not use
  				j = '\0';
  				break;

//			case SH_2:			// bank + button
// 			case '2':
//				if(hm == 'p'){
//					j = '\0';
//					i = update_bank(1);
//					do_2beep();
//				}
//				break;

/*			case SH_5:			// bank - button
			case '5':
				if(hm == 'p'){
//					j = '\0';
//					i = update_bank(0xff);
					do_1beep();
				}
				break;*/

/*			case SH_1:			// backlight BRT+
			case '1':
				if(hm == 'p'){
					// bright
//					j = backl_adj(0xff) + 1;
//					if(j > BRT_MAX) j = BRT_MAX;
//					backl_adj(BRT_PLUS);
					do_1beep();
				}
				j = '\0';
				break;*/

/*			case SH_4:			// backlight BRT-
			case '4':
				if(hm == 'p'){
					// dim
//					j = backl_adj(0xff) - 1;
//					if(j > BRT_MAX) j = 0;
//					backl_adj(BRT_MINUS);
					do_1beep();
				}
				j = '\0';
				break;*/

			case SH_8:
			case '8':
				j = DUPchrP;
				break;

			case SH_7:
			case '7':
				j = DUPchrM;
				break;

			case SH_9:
			case '9':
				j = DUPchrS;
				break;

			case SH_STR:
			case '*':
				j = TSchr;
				break;

			case SH_0:
			case '0':
				j = Tchr;
				break;
		}
	// map keys in normal mode
	}else{
		switch(cm){
			default:
				j = '\0';
				break;

			case '\\':					// process U/D press
				if(hm == 'p'){
					ud_hm133 -= 1;
					do_1beep();
				}
				j = '\0';
				break;

			case '/':
				if(hm == 'p'){
					ud_hm133 += 1;
					do_1beep();
				}
				j = '\0';
				break;

			case VMKEY:
				j = VMchr;
				break;

			case XFCKEY:
				if(hm == 'p'){
					j = MSchr;
				}
				break;

			case CALLKEY:
				j = CALLchr;
				break;

			case MWKEY:
				j = HILOchr;
				break;

			case F1KEY:
			case 'B':
				j = SUBchr;
				break;

			case 'D':
				j = SMUTEchr;
				break;

			case 'C':
				j = BANDchr;
				break;

			case 'A':
				j = Tchr;
				break;

			case '0':
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
				j = cm;
				break;

			case '#':
				if(is_dfe()){
					j = ENTchr;
				}else{
					j = CHKchr;
				}
				break;

			case '*':
				j = DOTchr;
				break;

/*			case 'A':
				j = CHKchr;
				break;*/

			case F2KEY:
			case SH_LOKEY:
				j = '\0';
				if(hm == 'p'){
					set_shift(1);
					shftm = 1;
					// update process indicator
					aprog(1);
					do_1beep();
					shft_time(1);									// start the shift timer
				}
				break;

			case LOKEY:
				j = MHZchr;
				break;
		}
	}
	// j == mapped key
	if(j){
		switch(hm){
		// process initial press
		case 'p':
			break;

		// process hold
		case 'h':
			j |= KHOLD_FLAG;
			break;

		default:
		case 'r':
		case 'R':
			j |= KREL_FLAG;
			hmk_time(0xff);
			break;
		}
		// store to buffer
		hm_sto(j);
	}
	return;
} // end key processing

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// set_shift() sets/clears func shift mode
//	returns shftm
//-----------------------------------------------------------------------------
U8 set_shift(U8 tf){

	if(tf == 1){
		shftm = 1;
		aprog(1);
		do_1beep();
		shft_time(1);								// start the shift timer
	}
	if(tf == 0){
		shftm = 0;
		aprog(0);
		do_2beep();
		shft_time(0xff);							// clear the shift timer
	}
	return shftm;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// process_CMD() handles periodic polling tasks for the cmd_fn.c file scope
//-----------------------------------------------------------------------------
char process_CMD(U8 flag){

	if(flag == PROC_INIT){
		// init file-local statics
		hm_hptr = 0;									// init MFmic head/tail buffer indexes
		hm_tptr = 0;
		ud_hm133 = 0;
//		shft_time(CLEAR_TIMER);							// clear timeout
		pttsub_togg(0);									// init pttsub statics
		send_stat(STAT_IPL, 0, (char*)NULL);
		return 0;
	}
	// process shift timeout -- turn off shift and execute beeps
/*	if((shftm) && !shft_time(0)){
		set_shift(0);									// un-shift and update DU status
	}*/
	// process CAT key hold
	if(key_hold){
/*		if(!cmd_time(0)){
			hm_map(key_hold, 'h');
			cmd_time(PSEC100MS);
		}*/
		if(!--key_count){
			hm_map(key_hold, 'r');
			key_hold = 0;
//			cmd_time(0xff);
			putsQ("#OKh$");
		}
	}
	return 0;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// got_hm_asc() returns true if there is a MFmic cmd waiting
//-----------------------------------------------------------------------------
U8 got_hm_asc(void){
	U8	rtn = '\0';

	if(hm_hptr != hm_tptr){
		rtn = 0xff;										// there is data
	}
	return rtn;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// hm_asc() fetches code characters from the MFmic input stream
//-----------------------------------------------------------------------------
U8 hm_asc(void){
	U8	rtn = '\0';

	if(hm_hptr != hm_tptr){
		rtn = hm_buf[hm_tptr++];						// get keypad code
		if(hm_tptr == HM_BUFF_END){						// update buf ptr w/ roll-over
			hm_tptr = 0;
		}
	}
	return rtn;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// hm_sto() stores kkey code characters to the MFmic input stream
//	does nothing if j == 0
//-----------------------------------------------------------------------------
void hm_sto(U8 j){

	if(j){
		// store to buffer
		hm_buf[hm_hptr++] = j;
		// Process rollover
		if(hm_hptr == HM_BUFF_END){
			hm_hptr = 0;
		}
		// Process overflow -- discards oldest entry
		if(hm_hptr == hm_tptr){
			hm_tptr += 1;
			if(hm_tptr == HM_BUFF_END){
				hm_tptr = 0;
			}
		}
	}
	return;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// pttsub_togg() issues call or smute toggle as an ersatz keypress based on
//	the bflags
//	!! For mode 4, we need to track MEM status since changes were made to how MEM/CALL
//		transitions are handled.  This also necessitates knowing the state of PTT
//j |= KREL_FLAG;
//-----------------------------------------------------------------------------
void pttsub_togg(U8 bflags){
//			U8	i=0;		// temp
//	static	U8	memcall;	// mem/call memory

//	i = bflags & PTTSUB_M;
/*	switch(i){
	// mode 1
	default:							// nop
		memcall = 0;					// init statics
		break;

	// mode 2
	case PTTSUB_SMUT:					// issue mute toggle
		hm_sto(SMUTEchr);
		break;*/

	// mode 3
/*	case PTTSUB_CALL:					// issue sub-call toggle
		hm_sto(SSUBchr);
		hm_sto(CALLchr);
		hm_sto(RSUBchr);
		break;*/

	// mode 4
/*	case PTTSUB_CALL|PTTSUB_SMUT:		// issue mem toggle
	if((xmode_stat(MAIN) & MEM_XFLAG) || (memcall & MEM_XFLAG)){
		// mem active...
		if(query_tx()){
			// save mem/call status
			memcall = xmode_stat(MAIN);
			hm_sto(MMAINchr);
			hm_sto(CALLchr);
			hm_sto(RMAINchr);
		}else{
			// restore mem status
			hm_sto(MMAINchr);
			hm_sto(MRchr);
			hm_sto(RMAINchr);
			memcall = 0;
		}
	}else{
		// VDO mode
		hm_sto(MMAINchr);
		hm_sto(CALLchr);
		hm_sto(RMAINchr);
	}

		break;
	}*/
	return;
}

//======================= UP/DN Fns ====================================

//-----------------------------------------------------------------------------
// updn14() processes U/D comparator and provides +/1 return.  Hold is also
//	processed, but need to add a signal for that (hold_flag is source for that
//	signal).
//-----------------------------------------------------------------------------
S8 updn14(void){
	S8	rtn = 0;
	static volatile U8 hold_flag;

	switch(ud_state){
	default:
		ud_state = UD_IDLE;
	case UD_IDLE:
		rtn = is_updn14();
		if(rtn != 0){
			udwait = HOLD_TIME;
			hold_flag = 0;
			do_dial_beep();								// beep
			ud_state = UD_UPDN;
		}
		break;

	case UD_UPDN:
		if(is_updn14() == 0){
			ud_state = UD_WAIT;
			udwait = DBNCE_TIME;
		}
		if(udwait == 0){
			hold_flag = TRUE;
		}
		break;

	case UD_WAIT:
		if(!udwait) ud_state = UD_IDLE;
		break;
	}
	rtn += ud_hm133;
	ud_hm133 = 0;
	return rtn;
}

//-----------------------------------------------------------------------------
// is_updn14() returns status of up/dn comparator buffer (ud_adc[])
//	return is based on ADC entries:
//	+1: up for all adc buffer entries
//	 0: open for all entries or not all entries are the same
//	-1: dn for all entries
//-----------------------------------------------------------------------------
S8 is_updn14(void){
	S8	rtn;
	S8	i;
	U8	idx;

	i = ud_adc[0];
	for(idx=1, rtn=0x70; idx<ADC_LEN; idx++){		// check to see if all buffer entries == index 0
		if(i != ud_adc[idx]) rtn = 0;				// if not ==, set open return
	}
	if(rtn != 0){									// if rtn not open, then there is a valid keypress state
		if(i & UP14){								// DN has prio since up will usu also be set here
			rtn = +1;
		}else{
			if(i & DN14) rtn = -1;					// test for up
			else rtn = 0;							// open is the remaining choice
		}
	}
	return rtn;
}

//==================== UART INTRPT Fns =================================

//-----------------------------------------------------------------------------
// rxd4_intr() UART rx intr (CLI I/O).  Captures RX data and places into
//	circular buffer
//-----------------------------------------------------------------------------
void rxd4_intr(void){
	char c;			// temp

	if(!(UART4_RIS_R & UART_RIS_RXRIS)){			// if intrpt is NOT rxd,
													// clear ALL intr flags and abort ISR
		UART4_ICR_R = UART_ICR_9BITIC|UART_ICR_OEIC|UART_ICR_BEIC|UART_ICR_PEIC|UART_ICR_FEIC|UART_ICR_RTIC|UART_ICR_TXIC|UART_ICR_CTSMIC;
		return;
		}
	while(!(UART4_FR_R & UART_FR_RXFE)){			// process RXD chrs
		c = UART4_DR_R;
		if((c == EOL) || (c == LF)){
			rxd4_buff[rxd4_hptr++] = '\0';			// EOL
			rxd4_mcnt++;
		}else{
			rxd4_buff[rxd4_hptr++] = c;				// feed the buffer
		}
		if(rxd4_hptr >= RXD4_BUFF_END){
			rxd4_hptr = 0;							// wrap buffer ptr
		}
		if(rxd4_hptr == rxd4_tptr){
			rxd4_stat |= RXD_ERR;					// buffer overrun, set error
		}
	}
	UART4_ICR_R = UART_ICR_RXIC;					// clear RXD intr flag
	return;
}

//-----------------------------------------------------------------------------
// Timer3A_ISR() drives ersatz ADC
//-----------------------------------------------------------------------------
//
// Called when timer 3A overflows (NORM mode):
//	Timer3_A runs as 16 bit reload timer
//	Reads comparator status, converts to 2-bit ADC and stores in ud_adc[] buffer
//	All buffer entries must be the same to render a state change
//
//-----------------------------------------------------------------------------
/*	if(1){
		TIMER3_CTL_R &= ~(TIMER_CTL_TAEN);				// disable timer
	}*/

void Timer3A_ISR(void)
{
	U8	i;		// temp

	if (udwait != 0){								// update wait timer
		udwait--;
	}

	i = (U8)(COMP_ACSTAT1_R & COMP_ACSTAT_OVAL);		// UP
	i |= (U8)(COMP_ACSTAT0_R & COMP_ACSTAT_OVAL)>>1;	// DN: capture up/dn into single U8
	ud_adc[ud_adc_idx++] = i;							// store to rolling buffer
	if(ud_adc_idx >= ADC_LEN) ud_adc_idx = 0;			// rollover adc index
	TIMER3_ICR_R = TIMER3_MIS_R & TIMERA_MIS_MASK;		// CLEAR TIMER FLAG
    return;
}

// eof serial4.c
