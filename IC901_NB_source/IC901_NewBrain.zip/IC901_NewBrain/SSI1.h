/********************************************************************
 ******* Changes COPYRIGHT (c) 2022 by KE0FF, Taylor, TX   **********
 *
 *  File name: SSI1.h
 *
 *  Module:    Control
 *
 *  Summary:
 *  This is the main file for the SSI1 driver (DATA1 out).
 *
 *  Project scope declarations revision history:
 *    08-25-15 jmh:  creation date
 *
 *******************************************************************/

/********************************************************************
 *  File scope declarations revision history:
 *    08-25-15 jmh:  creation date
 *
 *******************************************************************/

void ssi1_init(void);
