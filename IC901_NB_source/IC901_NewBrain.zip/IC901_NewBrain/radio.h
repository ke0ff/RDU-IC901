/********************************************************************
 ************ COPYRIGHT (c) 2025 by KE0FF, Taylor, TX   *************
 *
 *  File name: radio.h
 *
 *  Module:    Control
 *
 *  Summary:   defines and global declarations for radio.c
 *
 *******************************************************************/

#include "typedef.h"
#include <stdint.h>
#include "sio.h"


//-----------------------------------------------------------------------------
// Definitions
//-----------------------------------------------------------------------------
// Processor I/O assignments
// ...see init.h

#define	MAIN	1
#define	SUB		0

#define	LEN_VFO_ARY		(ID1200)
#define	LEN_ARY			(ID1200)
#define	LEN_HIB			(56/4)	//(6*(LEN_VFO_ARY + 5))
#define	XIT_HIB_ADR		3
#define	RIT_HIB_ADR		7

// VFO defines
#define	MAX_VFO	1350000000L			// max valid VFO
// VFO struct
struct vfo_struct {
	U32	vfo;						// main vfo frequency (RX) in KHz
	U16	offs;						// TX offset in KHz
	U8	dplx;						// duplex/RFpwr/XIT/MEM - packed flags for each resource
	U8	ctcss;						// PL setting and "OFF" control bit
	U8	sq;							// SQ setting
	U8	vol;						// VOL setting
	U8	mem;						// current mem#
	U8	call;						// current call#
	U8	bflags;						// expansion flags
	U8	scanflags;					// scan flags (expansion)
	U8	tsa;						// frq step "A" setting
	U8	tsb;						// frq step "B" setting
};

////////////////////////////////////////////////////////////////////////////////////////////////
// NVRAM memory map
//=====================================================================================================
// NVRAM memory map
#define	NVRAM_BASE	(0L)
#define	NVRAM_MAX	131072L

// Global data resides in the first 128 bytes of NVRAM
#define	XIT_0		(NVRAM_BASE)							// xit reg
#define	RIT_0		(XIT_0 + sizeof(U8))					// rit reg
#define	BIDM_0		(RIT_0 + sizeof(U8))					// bandidm reg
#define	BIDS_0		(BIDM_0 + sizeof(U16))					// bandids reg

#define	XMODET_0	(BIDS_0 + sizeof(U16))					// xmode flags, one per domain

#define	TXULIM_0	(XMODET_0 + ((sizeof(U8) * ID2MSSB)))	// TX upper limits (per band domain)
#define	TXLLIM_0	(TXULIM_0 + ((sizeof(U32) * ID2MSSB)))	// TX lower limits (per band domain)

#define	LIM_END		(TXLLIM_0 + ((sizeof(U32) * ID2MSSB)))	// reserved space

#define	RESERVED0	(128 - LIM_END)							// reserved segment

// Each VFO is stored to NVRAM as a "union" with individual elements of disparate arrays
// grouped together to reduce SPI transfer overhead.  This allows all elements of a VFO to
// be updated by a single SPI transfer
#define	VFO_0		(LIM_END + RESERVED0)		// main vfo freq
#define	OFFS_0		(VFO_0 + (sizeof(U32)))		// TX offset freq
#define	DPLX_0		(OFFS_0 + (sizeof(U16)))	// duplex/RFpwr/XIT/MEM
#define	CTCSS_0		(DPLX_0 + sizeof(U8))		// PL setting
#define	SQ_0		(CTCSS_0 + sizeof(U8))		// SQ
#define	VOL_0		(SQ_0 + sizeof(U8))			// VOL
#define	MEM_0		(VOL_0 + sizeof(U8))		// mem#
#define	CALL_0		(MEM_0 + sizeof(U8))		// call-mem#
#define	MEM_ARY_0	(CALL_0 + sizeof(U8))		// mem array#
#define CALL_ARY_0	(MEM_ARY_0 + sizeof(U8))	// call array#
#define	BFLAGS_0	(CALL_ARY_0 + sizeof(U8))	// expansion flags
#define	PTTSUB_SMUT	0x40						// ptt-sub edge action mode bits and field mask
#define	PTTSUB_CALL	0x80
#define	PTTSUB_bs	6
#define	PTTSUB_M	(PTTSUB_SMUT | PTTSUB_CALL)
#define	PTTSUB_MOD0	0
#define	PTTSUB_MOD1	PTTSUB_SMUT
#define	PTTSUB_MOD2	PTTSUB_CALL
#define	PTTSUB_MOD3	(PTTSUB_SMUT | PTTSUB_CALL)

#define	SCANFLAGS_0	(BFLAGS_0 + sizeof(U8))		// scan (expansion) flags
#define	TSA_0		(SCANFLAGS_0 + sizeof(U8))	// frq step "A"
#define	TSB_0		(TSA_0 + sizeof(U8))		// frq step "B"
#define	BAND_END	(TSB_0 + sizeof(U8))
#define	VFO_LEN		(BAND_END - VFO_0)
#define	VFO_END		((VFO_LEN * NUM_VFOS) + VFO_0)

#define	IDX_VFO		0							// Byte address offsets for NVRAM addressing
#define	IDX_OFFS	(OFFS_0 - VFO_0)
#define	IDX_DPLX	(DPLX_0 - VFO_0)
#define	IDX_CTCSS	(CTCSS_0 - VFO_0)
#define	IDX_SQ		(SQ_0 - VFO_0)
#define	IDX_VOL		(VOL_0 - VFO_0)
#define	IDX_MEM		(MEM_0 - VFO_0)
#define	IDX_CALL	(CALL_0 - VFO_0)
#define	IDX_MEM_ARY	(MEM_ARY_0 - VFO_0)
#define IDX_CALL_ARY	(CALL_ARY_0 - VFO_0)
#define	IDX_BFLAGS	(BFLAGS_0 - VFO_0)
#define	IDX_SCANFLAGS (SCANFLAGS_0 - VFO_0)
#define	IDX_TSA		(TSA_0 - VFO_0)
#define	IDX_TSB		(TSB_0 - VFO_0)

// MEM space //
#define	MEM_NAME_LEN	16
#define	MEM0_BASE	(VFO_END)

// mem structure follows this format:
// [VFO + OFFS + DPLX + CTCSS + SQ + VOL] + [XIT + RIT + BID] + MEM_NAME_LEN
#define	MEM_STR_ADDR (sizeof(U32) + sizeof(U16) + (sizeof(U8) * 7))
#define	MEM_LEN		(MEM_STR_ADDR + MEM_NAME_LEN)
#define	MAX_MEM		30
#define	MAX_MEM2	(MAX_MEM * 2)			// double the IC900 mem space
#define	CALL_MEM	MAX_MEM2
#define	NUM_MEMS	(CALL_MEM + 4)			// 60 mems, + 4 call mems

// Each mem consists of a mem name string (ASCII), the VFO struct, and XIT/BID metas
#define	ID10M_MEM	MEM0_BASE
#define	ID6M_MEM	(ID10M_MEM + (NUM_MEMS * MEM_LEN))
#define	ID2M_MEM	(ID6M_MEM + (NUM_MEMS * MEM_LEN))
#define	ID220_MEM	(ID2M_MEM + (NUM_MEMS * MEM_LEN))
#define	ID440_MEM	(ID220_MEM + (NUM_MEMS * MEM_LEN))
#define	ID1200_MEM	(ID440_MEM + (NUM_MEMS * MEM_LEN))
#define	IDR91_MEM	(ID1200_MEM + (NUM_MEMS * MEM_LEN))
#define	IDS92_MEM	(IDR91_MEM + (NUM_MEMS * MEM_LEN))
#define	MEM_END		(IDS92_MEM + (NUM_MEMS * MEM_LEN))

#define	VFO_CRC		MEM_END
#define	MEM_CRC		(VFO_CRC + sizeof(U16))
// buffer 12 more bytes here
#define	CRC_END		(VFO_CRC + (sizeof(U16)*8))

#define	BANK_LEN	(NVRAM_MAX/10)				// NVRAM divided into 10 equal segments
#define	IDLE_BANK	0xff						// no bank-change signal
#define	NVBANK_MAX	5							// max # memory banks

// radio config data
#define	CONFIG_MEM	((NVBANK_MAX * MEM_END) + 16)
#define	BRTADDR		CONFIG_MEM
#define	DIMADDR		(BRTADDR+1)
#define	DIMSTATADDR	(DIMADDR+1)

//=====================================================================================================
// EEPROM memory map

#define	EEARRAY_LEN	(2)
#define	EESRT		0						// EEPROM address map
#define	CALL_LEN	(6+2)					// 6 chr + null + chksum (!! MUST BE EVEN MULTIPLE OF 4 !!)
#define	CALL_EE		(EESRT+EEARRAY_LEN)
#define	SNUM_LEN	1						// 4 bytes
#define	SNUM_EE		CALL_EE	+ (CALL_LEN/4)

//////////////////////////////////////////////////////////////
// CTCSS flags
#define	CTCSS_MASK		0x3F				// tone code mask
#define	TONE_MAX		38					// max # PL tones
#define	CTCSS_OFF		0x80				// CTCSS off flag

// duplex/RFpwr flag bits
#define	DPLX_S			0x00				// simplex
#define	DPLX_P			0x01				// plus
#define	DPLX_M			0x02				// minus
#define	DPLX_MASK		(DPLX_P | DPLX_M)	// field mask
#define	LOHI_F			0x04				// low power if == 1
#define	TSA_F			0x08				// use TSA if == 1
#define	SCANEN_F		0x10				// mem scan enable flag ("S"kip = on if zero)

#define	XIT_REG			0x0f				// xit register (0x08 is dir, 0x07 is count)

#define	SIN_ACTIVITY	200		// SIN activity timeout

// update_radio_all ordinal defines
#define	UPDATE_ALL		1
#define	MAIN_ALL		2
#define	SUB_ALL			3
#define	MAIN_FREQ		4
#define	SUB_FREQ		5
#define	MAIN_VQ			6
#define	SUB_VQ			7

// PTT mem defines
#define	NO_PTT			0
#define	PTT_KEYED		1
#define	PTT_EDGE		0x80
/*
// SIN activity flag bits
#define SIN_SQSM_F		SIN_SQSA					// COS main
#define SIN_SQSM_CF		SIN_SQSA_CF					// COS main
#define SIN_SQSS_F		SIN_SQSB					// COS sub
#define SIN_SQSS_CF		SIN_SQSB_CF					// COS sub
//#define SIN_MSRF_F		SIN_SRFA					// SRF main
#define SIN_MSRF_CF		SIN_SRFA_CF					// SRF main
//#define SIN_SSRF_F		SIN_SRFB					// SRF sub
#define SIN_SSRF_CF		SIN_SRFB_CF					// SRF sub
#define SIN_SEND_F		SIN_SEND					// PTT
//#define SIN_SEND_CF		SIN_SEND_CF					// PTT
#define SIN_DSQ_F		(SIN_DSQA|SIN_DSQB)			// tone detected
#define SIN_DSQ_CF		(SIN_DSQA_CF|SIN_DSQB_CF)	// tone detected
#define SIN_DSQA_F		SIN_DSQA					// tone detected
//#define SIN_DSQA_CF		SIN_DSQA_CF					// tone detected
#define SIN_DSQB_F		SIN_DSQB					// tone detected
//#define SIN_DSQB_CF		SIN_DSQB_CF					// tone detected
#define SIN_MUD_M		(SIN_MUP|SIN_MDN)			// MIC u/d button change mask
#define SIN_MUD_CFM		(SIN_MUP_CF|SIN_MDN_CF)		// MIC u/d button change mask
#define SIN_SEL_M		(SIN_TONE|SIN_OPT1|SIN_OPT2|SIN_OPT3)	// OPT mask
#define SIN_SEL_CFM		(SIN_TONE_CF|SIN_OPT1_CF|SIN_OPT2_CF|SIN_OPT3_CF)	// OPT mask
#define	SIN_VFOM_CF		0x00100000L					// vfo change flag
#define	SIN_VFOS_CF		0x00200000L					// vfo change flag
#define SIN_SINACTO_F	0x40000000L					// SIN timeout has occurred
#define SIN_PRSNTERR_F	0x20000000L					// SIN duplicate UX present msg recedived (error)
*/
// SOUT signal flag bits
#define	PLL_EOL			0xff00000000000000LL

#define SOUT_TONE_F		0x01	// tone update
#define SOUT_TONE_N		0x00	// tone ordinal
#define SOUT_MSQU_F		0x02	// main squ update SIN_VFOM_F
#define SOUT_MSQU_N		0x01	// msqu ordinal
#define SOUT_SSQU_F		0x04	// sub squ update
#define SOUT_SSQU_N		0x02	// ssqu ordinal
#define SOUT_MVOL_F		0x08	// main vol update
#define SOUT_MVOL_N		0x03	// mvol ordinal
#define SOUT_SVOL_F		0x10	// sub vol update
#define SOUT_SVOL_N		0x04	// svol ordinal
#define SOUT_VUPD_F		0x20	// force vfo push update
#define SOUT_VUPD_N		0x05	// force vfo push ordinal
#define SOUT_VFOS_F		0x40	// sub vfo update
#define SOUT_VFOS_N		0x06	// svfo ordinal
#define SOUT_VFOM_F		0x80	// mvfo vfo update
#define SOUT_VFOM_N		0x07	// tone ordinal

#define	XPOLY	0x1021			// crc polynomial
//#define	HIB_SEL	0
//#define	VFO_SEL	1
#define	CRC_HIB_ADDR	62		// CRC16 goes at top 2 bytes of HIB RAM

#define	SYS_ERR_WAIT	2			// is 500 for IC900 RDU
#define	MHZ_TIME		SEC10		// MHZ digit mode timeout
#define	VQ_TIME			SEC3		// vol/squ adj timeout
#define	SET_TIME		(3*SEC10)	// set mode timeout
#define	SUB_TIME		(3*SEC10)	// sub-focus timeout
#define	MIC_RPT_TIME	80			// mic u/d button 80ms repeat period
#define	MIC_RPT_WAIT	1000		// mic u/d button repeat wait period
#define	MIC_DB_TIME		20			// mic u/d button debounce wait period
#define	MUTE_TIME		250			// volume mute delay for band swaps
#define	TSW_TIME		SEC10		// TS adj timeout
#define	SLIDE_TIME		SEC300MS	// text slider display shift rate
#define	SCAN_TIME		SEC400MS	// scan channel rate
#define	SCAN_TIME2		SEC1		// scan channel LOS hold time
#define	SCAN_TIME3		SEC100MS	// scan band switch debounce time
#define	SCAN_TIME4		(SCAN_TIME - SCAN_TIME3)	// scan band switch debounce time
#define	IPL_TIME		SEC5		// volume mute delay for band swaps

// set/read_tsab():
#define	TSA_SEL			1			// selects TSA
#define	TSB_SEL			2			// selects TSB
#define	TS_5			1			// 5 KHz step
#define	TS_10			2			// 10 KHz step
#define	TS_25			5			// 25 KHz step

//-----------------------------------------------------------------------------
// Global Fns
//-----------------------------------------------------------------------------

void init_radio(void);
void process_SIN(U8 cmd);
U8 process_SOUT(U8 cmd);
void  save_vfo(U8 b_id);
//void  save_v(U8 focus);
//void  save_q(U8 focus);
void  recall_vfo(void);
//U16 crc_vfo(void);
U16 crc_hib(void);
U16 calcrc(U8 c, U16 oldcrc);
void push_vfo(void);
U32 fetch_sin(U8 addr);
U32 read_sin_flags(U32 flag);
void vfo_change(U8 band);
uint64_t* setpll(U8 bid, uint64_t* plldata, U8 is_tx, U8 is_main);
void  set_present(U16 ii);
U8  get_present(void);
//U32 set_squ(U8 mainsub);
//U32 set_vol(U8 mainsub);
U32 atten_calc(U8 aval);
U8 adjust_squ(U8 mainsub, S8 value);
U8 adjust_vol(U8 mainsub, S8 value);
U8 adjust_tone(U8 mainsub, S8 value);
U8 adjust_toneon(U8 mainsub, U8 value);
U8 inc_dplx(U8 main);
void write_dplx(U8 main, U8 dup);
U8 read_dplx(U8 main);
S8 add_vfo(U8 main, S8 adder, U8 daddr);
U8 get_band_index(U8 main);
U16 set_next_band(U8 focus);
U16 set_swap_band(void);
U8 read_tsab(U8 main, U8 absel);
void set_tsab(U8 main, U8 absel, U8 value);
void set_ab(U8 main, U8 tf);
S32 set_mhz_step(S32 sval);
void put_updn2(char kcode);
S8 is_mic_updn(U8 ipl, U8 focus, U8 xmq);
U32 get_freq(U8 focust);
void copy_vfot(U8 main);
void copy_2vfo(U8 main, U32 vfod);
void temp_vfo(U8 main);
U32 get_vfo(U8 focus);
U32 get_vfot(void);
void  force_push_radio(U8 flag);
U8 get_lohi(U8 bid, U8 setread);
U8 get_memnum(U8 main, U8 adder);
U8 get_callnum(U8 main, S8 adder);
U8 get_bit(U16 value);
U16 set_bit(U8 value);
U8 bit_set(U16 value);
void  update_radio_all(U8 vector);
void set_offs(U8 focus, U16 value);
U16 get_offs(U8 focus);
U8 inv_duplex(U8 focus);
U8 inv_vfo(U8 focus);
void mute_radio(U8 mutefl);
U8 get_mute_radio(void);
void set_bandid(U8 focus, U8 b_id);
void set_boff(U8 focus, U8 boffid);
void write_mem(U8 focus, U8 memnum);
void read_mem(U8 focus, U8 memnum);
void write_nvmem(U8 band, U8 memnum);
void read_nvmem(U8 band, U8 memnum);
void copy_vfo2temp(U8 focus);
void copy_temp2vfo(U8 focus);
void save_mc(U8 focus);
char* get_nameptr(U8 focus);
void set_bandnv(void);
void set_qnv(U8 focus);
void set_vnv(U8 focus);
void set_tonenv(U8 focus);
U8 get_scanmem(U8 focus);
U8 get_scanen(U8 bid, U8 memnum);
U8 togg_scanmem(U8 focus);
U32 get_memaddr(U8 band, U8 memnum);
void set_memnum(U8 bid, S8 memnum);
void init_vfos(U8 update);
void write_nvvfo(U8 band);
U8 get_is_tx(void);
U8  get_bflag(U8 focus, U8 cmd, U8 bfset);
U8 get_srf(U8 focus);
U8 get_cos(void);
U8 get_changestat(void);
U8 get_modulid(U32 freqMM);
void put_vfo(U8 focus, char* sptr, U8 sid);
void set_vfo(U32 freq, U8 bid);
void set_offs2(U32 freq, U8 bid);
void set_ctcss(U8 code, U8 bid);
void set_ctcsson(U8 ton, U8 bid);
void set_vol(U8 code, U8 bid);
void set_squ(U8 code, U8 bid);
void set_tsa(U8 step, U8 bid);
void set_tsb(U8 step, U8 bid);
void set_dplx(U8 dup, U8 bid);
void set_lohi(U8 lohi, U8 bid);
U8 set_pttsub(U8 pttsub, U8 bid);
U32 nvaddr(U32 addrin, U8 cmd);
U8 nvbank_nxt(U8 tf);
void set_boff(U8 focus, U8 boffid);
U8 get_ctcss(U8 focus);
U8 save_ee(U16 eeaddr);
U8 get_rit(void);
U8 get_xit(void);
U32 get_freqb(U8 bid);
U32 get_offsb(U8 bid);
void pass_ud(U32 saddr1);

U8 strchks(char* s);
char strcall(char* s);
U8 valid_rcall(void);
void rcall2ee(char* s);
void ee2rcall(char* s);
char* getrcall_ptr(void);

void nvbank_dbg(char* s);

U8 nvbank_nxt(U8 tf);
